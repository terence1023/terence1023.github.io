```python
# 导入所需的package
import seaborn as sns #用于画图
from bs4 import BeautifulSoup #用于爬取arxiv的数据
import re #用于正则表达式，匹配字符串的模式
import requests #用于网络连接，发送网络请求，使用域名获取对应信息
import json #读取数据，我们的数据为json格式的
import pandas as pd #数据处理，数据分析
import matplotlib.pyplot as plt #画图工具
```


```python
data = []
with open("../data/arxiv-metadata-oai-snapshot.json", 'r') as f:
    for line in f:
        data.append(json.loads(line))
print(type(data))
data = pd.DataFrame(data)
print(type(data))
data.shape
```

    <class 'list'>
    <class 'pandas.core.frame.DataFrame'>
    




    (1796911, 14)




```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>submitter</th>
      <th>authors</th>
      <th>title</th>
      <th>comments</th>
      <th>journal-ref</th>
      <th>doi</th>
      <th>report-no</th>
      <th>categories</th>
      <th>license</th>
      <th>abstract</th>
      <th>versions</th>
      <th>update_date</th>
      <th>authors_parsed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0704.0001</td>
      <td>Pavel Nadolsky</td>
      <td>C. Bal\'azs, E. L. Berger, P. M. Nadolsky, C.-...</td>
      <td>Calculation of prompt diphoton production cros...</td>
      <td>37 pages, 15 figures; published version</td>
      <td>Phys.Rev.D76:013009,2007</td>
      <td>10.1103/PhysRevD.76.013009</td>
      <td>ANL-HEP-PR-07-12</td>
      <td>hep-ph</td>
      <td>None</td>
      <td>A fully differential calculation in perturba...</td>
      <td>[{'version': 'v1', 'created': 'Mon, 2 Apr 2007...</td>
      <td>2008-11-26</td>
      <td>[[Balázs, C., ], [Berger, E. L., ], [Nadolsky,...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0704.0002</td>
      <td>Louis Theran</td>
      <td>Ileana Streinu and Louis Theran</td>
      <td>Sparsity-certifying Graph Decompositions</td>
      <td>To appear in Graphs and Combinatorics</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>math.CO cs.CG</td>
      <td>http://arxiv.org/licenses/nonexclusive-distrib...</td>
      <td>We describe a new algorithm, the $(k,\ell)$-...</td>
      <td>[{'version': 'v1', 'created': 'Sat, 31 Mar 200...</td>
      <td>2008-12-13</td>
      <td>[[Streinu, Ileana, ], [Theran, Louis, ]]</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0704.0003</td>
      <td>Hongjun Pan</td>
      <td>Hongjun Pan</td>
      <td>The evolution of the Earth-Moon system based o...</td>
      <td>23 pages, 3 figures</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>physics.gen-ph</td>
      <td>None</td>
      <td>The evolution of Earth-Moon system is descri...</td>
      <td>[{'version': 'v1', 'created': 'Sun, 1 Apr 2007...</td>
      <td>2008-01-13</td>
      <td>[[Pan, Hongjun, ]]</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0704.0004</td>
      <td>David Callan</td>
      <td>David Callan</td>
      <td>A determinant of Stirling cycle numbers counts...</td>
      <td>11 pages</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>math.CO</td>
      <td>None</td>
      <td>We show that a determinant of Stirling cycle...</td>
      <td>[{'version': 'v1', 'created': 'Sat, 31 Mar 200...</td>
      <td>2007-05-23</td>
      <td>[[Callan, David, ]]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0704.0005</td>
      <td>Alberto Torchinsky</td>
      <td>Wael Abu-Shammala and Alberto Torchinsky</td>
      <td>From dyadic $\Lambda_{\alpha}$ to $\Lambda_{\a...</td>
      <td>None</td>
      <td>Illinois J. Math. 52 (2008) no.2, 681-689</td>
      <td>None</td>
      <td>None</td>
      <td>math.CA math.FA</td>
      <td>None</td>
      <td>In this paper we show how to compute the $\L...</td>
      <td>[{'version': 'v1', 'created': 'Mon, 2 Apr 2007...</td>
      <td>2013-10-15</td>
      <td>[[Abu-Shammala, Wael, ], [Torchinsky, Alberto, ]]</td>
    </tr>
  </tbody>
</table>
</div>




```python
data = data[['id', 'categories', 'update_date']]
print(data.shape)
data.head()
```

    (1796911, 3)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>update_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0704.0001</td>
      <td>hep-ph</td>
      <td>2008-11-26</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0704.0002</td>
      <td>math.CO cs.CG</td>
      <td>2008-12-13</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0704.0003</td>
      <td>physics.gen-ph</td>
      <td>2008-01-13</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0704.0004</td>
      <td>math.CO</td>
      <td>2007-05-23</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0704.0005</td>
      <td>math.CA math.FA</td>
      <td>2013-10-15</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>update_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1796911</td>
      <td>1796911</td>
      <td>1796911</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>1796907</td>
      <td>62055</td>
      <td>4095</td>
    </tr>
    <tr>
      <th>top</th>
      <td>math-ph/0408005</td>
      <td>astro-ph</td>
      <td>2007-05-23</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>2</td>
      <td>86914</td>
      <td>130748</td>
    </tr>
  </tbody>
</table>
</div>




```python
unique_categories = set([i for l in [x.split(' ') for x in data['categories']] for i in l])
print(len(unique_categories))
unique_categories
```

    176
    




    {'acc-phys',
     'adap-org',
     'alg-geom',
     'ao-sci',
     'astro-ph',
     'astro-ph.CO',
     'astro-ph.EP',
     'astro-ph.GA',
     'astro-ph.HE',
     'astro-ph.IM',
     'astro-ph.SR',
     'atom-ph',
     'bayes-an',
     'chao-dyn',
     'chem-ph',
     'cmp-lg',
     'comp-gas',
     'cond-mat',
     'cond-mat.dis-nn',
     'cond-mat.mes-hall',
     'cond-mat.mtrl-sci',
     'cond-mat.other',
     'cond-mat.quant-gas',
     'cond-mat.soft',
     'cond-mat.stat-mech',
     'cond-mat.str-el',
     'cond-mat.supr-con',
     'cs.AI',
     'cs.AR',
     'cs.CC',
     'cs.CE',
     'cs.CG',
     'cs.CL',
     'cs.CR',
     'cs.CV',
     'cs.CY',
     'cs.DB',
     'cs.DC',
     'cs.DL',
     'cs.DM',
     'cs.DS',
     'cs.ET',
     'cs.FL',
     'cs.GL',
     'cs.GR',
     'cs.GT',
     'cs.HC',
     'cs.IR',
     'cs.IT',
     'cs.LG',
     'cs.LO',
     'cs.MA',
     'cs.MM',
     'cs.MS',
     'cs.NA',
     'cs.NE',
     'cs.NI',
     'cs.OH',
     'cs.OS',
     'cs.PF',
     'cs.PL',
     'cs.RO',
     'cs.SC',
     'cs.SD',
     'cs.SE',
     'cs.SI',
     'cs.SY',
     'dg-ga',
     'econ.EM',
     'econ.GN',
     'econ.TH',
     'eess.AS',
     'eess.IV',
     'eess.SP',
     'eess.SY',
     'funct-an',
     'gr-qc',
     'hep-ex',
     'hep-lat',
     'hep-ph',
     'hep-th',
     'math-ph',
     'math.AC',
     'math.AG',
     'math.AP',
     'math.AT',
     'math.CA',
     'math.CO',
     'math.CT',
     'math.CV',
     'math.DG',
     'math.DS',
     'math.FA',
     'math.GM',
     'math.GN',
     'math.GR',
     'math.GT',
     'math.HO',
     'math.IT',
     'math.KT',
     'math.LO',
     'math.MG',
     'math.MP',
     'math.NA',
     'math.NT',
     'math.OA',
     'math.OC',
     'math.PR',
     'math.QA',
     'math.RA',
     'math.RT',
     'math.SG',
     'math.SP',
     'math.ST',
     'mtrl-th',
     'nlin.AO',
     'nlin.CD',
     'nlin.CG',
     'nlin.PS',
     'nlin.SI',
     'nucl-ex',
     'nucl-th',
     'patt-sol',
     'physics.acc-ph',
     'physics.ao-ph',
     'physics.app-ph',
     'physics.atm-clus',
     'physics.atom-ph',
     'physics.bio-ph',
     'physics.chem-ph',
     'physics.class-ph',
     'physics.comp-ph',
     'physics.data-an',
     'physics.ed-ph',
     'physics.flu-dyn',
     'physics.gen-ph',
     'physics.geo-ph',
     'physics.hist-ph',
     'physics.ins-det',
     'physics.med-ph',
     'physics.optics',
     'physics.plasm-ph',
     'physics.pop-ph',
     'physics.soc-ph',
     'physics.space-ph',
     'plasm-ph',
     'q-alg',
     'q-bio',
     'q-bio.BM',
     'q-bio.CB',
     'q-bio.GN',
     'q-bio.MN',
     'q-bio.NC',
     'q-bio.OT',
     'q-bio.PE',
     'q-bio.QM',
     'q-bio.SC',
     'q-bio.TO',
     'q-fin.CP',
     'q-fin.EC',
     'q-fin.GN',
     'q-fin.MF',
     'q-fin.PM',
     'q-fin.PR',
     'q-fin.RM',
     'q-fin.ST',
     'q-fin.TR',
     'quant-ph',
     'solv-int',
     'stat.AP',
     'stat.CO',
     'stat.ME',
     'stat.ML',
     'stat.OT',
     'stat.TH',
     'supr-con'}




```python
data["year"] = pd.to_datetime(data["update_date"]).dt.year
del data["update_date"]
data = data[data["year"] >= 2019]
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>296</th>
      <td>0704.0297</td>
      <td>astro-ph</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>341</th>
      <td>0704.0342</td>
      <td>math.AT</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>359</th>
      <td>0704.0360</td>
      <td>astro-ph</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>524</th>
      <td>0704.0525</td>
      <td>gr-qc</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>534</th>
      <td>0704.0535</td>
      <td>astro-ph</td>
      <td>2019</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.groupby(["categories", "year"])
data.reset_index(drop=True, inplace=True)
print(data.shape)
data.head()
```

    (395123, 3)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0704.0297</td>
      <td>astro-ph</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0704.0342</td>
      <td>math.AT</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0704.0360</td>
      <td>astro-ph</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0704.0525</td>
      <td>gr-qc</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0704.0535</td>
      <td>astro-ph</td>
      <td>2019</td>
    </tr>
  </tbody>
</table>
</div>




```python
data_new = data.sort_values(['year', 'categories'], ascending=[True, True]).head()
data_new.reset_index(drop=True, inplace=True)
data_new.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>acc-phys/9505002</td>
      <td>acc-phys hep-ex physics.acc-ph</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>1</th>
      <td>acc-phys/9510001</td>
      <td>acc-phys physics.acc-ph</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>2</th>
      <td>adap-org/9709006</td>
      <td>adap-org chao-dyn nlin.AO nlin.CD</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>3</th>
      <td>adap-org/9903004</td>
      <td>adap-org cond-mat.dis-nn nlin.AO</td>
      <td>2019</td>
    </tr>
    <tr>
      <th>4</th>
      <td>adap-org/9312001</td>
      <td>adap-org nlin.AO</td>
      <td>2019</td>
    </tr>
  </tbody>
</table>
</div>




```python
#爬取所有的类别
website_url = requests.get('https://arxiv.org/category_taxonomy').text #获取网页的文本数据
soup = BeautifulSoup(website_url,'lxml') #爬取数据，这里使用lxml的解析器，加速
root = soup.find('div',{'id':'category_taxonomy_list'}) #找出 BeautifulSoup 对应的标签入口
tags = root.find_all(["h2","h3","h4","p"], recursive=True) #读取 tags

#初始化 str 和 list 变量
level_1_name = ""
level_2_name = ""
level_2_code = ""
level_1_names = []
level_2_codes = []
level_2_names = []
level_3_codes = []
level_3_names = []
level_3_notes = []

#进行
for t in tags:
    if t.name == "h2":
        level_1_name = t.text    
        level_2_code = t.text
        level_2_name = t.text
    elif t.name == "h3":
        raw = t.text
        level_2_code = re.sub(r"(.*)\((.*)\)",r"\2",raw) #正则表达式：模式字符串：(.*)\((.*)\)；被替换字符串"\2"；被处理字符串：raw
        level_2_name = re.sub(r"(.*)\((.*)\)",r"\1",raw)
    elif t.name == "h4":
        raw = t.text
        level_3_code = re.sub(r"(.*) \((.*)\)",r"\1",raw)
        level_3_name = re.sub(r"(.*) \((.*)\)",r"\2",raw)
    elif t.name == "p":
        notes = t.text
        level_1_names.append(level_1_name)
        level_2_names.append(level_2_name)
        level_2_codes.append(level_2_code)
        level_3_names.append(level_3_name)
        level_3_codes.append(level_3_code)
        level_3_notes.append(notes)

#根据以上信息生成dataframe格式的数据
df_taxonomy = pd.DataFrame({
    'group_name' : level_1_names,
    'archive_name' : level_2_names,
    'archive_id' : level_2_codes,
    'category_name' : level_3_names,
    'categories' : level_3_codes,
    'category_description': level_3_notes
    
})

#按照 "group_name" 进行分组，在组内使用 "archive_name" 进行排序
df_taxonomy.groupby(["group_name","archive_name"])
df_taxonomy
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>group_name</th>
      <th>archive_name</th>
      <th>archive_id</th>
      <th>category_name</th>
      <th>categories</th>
      <th>category_description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Artificial Intelligence</td>
      <td>cs.AI</td>
      <td>Covers all areas of AI except Vision, Robotics...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Hardware Architecture</td>
      <td>cs.AR</td>
      <td>Covers systems organization and hardware archi...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computational Complexity</td>
      <td>cs.CC</td>
      <td>Covers models of computation, complexity class...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computational Engineering, Finance, and Science</td>
      <td>cs.CE</td>
      <td>Covers applications of computer science to the...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computational Geometry</td>
      <td>cs.CG</td>
      <td>Roughly includes material in ACM Subject Class...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>150</th>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Computation</td>
      <td>stat.CO</td>
      <td>Algorithms, Simulation, Visualization</td>
    </tr>
    <tr>
      <th>151</th>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Methodology</td>
      <td>stat.ME</td>
      <td>Design, Surveys, Model Selection, Multiple Tes...</td>
    </tr>
    <tr>
      <th>152</th>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Machine Learning</td>
      <td>stat.ML</td>
      <td>Covers machine learning papers (supervised, un...</td>
    </tr>
    <tr>
      <th>153</th>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Other Statistics</td>
      <td>stat.OT</td>
      <td>Work in statistics that does not fit into the ...</td>
    </tr>
    <tr>
      <th>154</th>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Statistics</td>
      <td>Statistics Theory</td>
      <td>stat.TH</td>
      <td>stat.TH is an alias for math.ST. Asymptotics, ...</td>
    </tr>
  </tbody>
</table>
<p>155 rows × 6 columns</p>
</div>




```python
df = data.merge(df_taxonomy, on="categories", how="left").drop_duplicates(["id", "group_name"]).groupby("group_name").\
        agg({"id":"count"}).sort_values(by="id", ascending=False).reset_index()
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>group_name</th>
      <th>id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Physics</td>
      <td>79985</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mathematics</td>
      <td>51567</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computer Science</td>
      <td>40067</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Statistics</td>
      <td>4054</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Electrical Engineering and Systems Science</td>
      <td>3297</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Quantitative Biology</td>
      <td>1994</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Quantitative Finance</td>
      <td>826</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Economics</td>
      <td>576</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_1 = data.merge(df_taxonomy, on="categories", how="left").drop_duplicates(["id", "group_name"]).groupby("group_name").\
        agg({"id":[('count_', 'count')]}).sort_values(by=('id', 'count_'), ascending=False).reset_index()
df_1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>group_name</th>
      <th>id</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th>count_</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Physics</td>
      <td>79985</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mathematics</td>
      <td>51567</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computer Science</td>
      <td>40067</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Statistics</td>
      <td>4054</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Electrical Engineering and Systems Science</td>
      <td>3297</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Quantitative Biology</td>
      <td>1994</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Quantitative Finance</td>
      <td>826</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Economics</td>
      <td>576</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_1.columns
```




    MultiIndex([('id', 'count_')],
               )




```python
df = df.rename(columns={'id':'count'})
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>group_name</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Physics</td>
      <td>79985</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mathematics</td>
      <td>51567</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computer Science</td>
      <td>40067</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Statistics</td>
      <td>4054</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Electrical Engineering and Systems Science</td>
      <td>3297</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Quantitative Biology</td>
      <td>1994</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Quantitative Finance</td>
      <td>826</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Economics</td>
      <td>576</td>
    </tr>
  </tbody>
</table>
</div>




```python
fig, ax = plt.subplots(figsize=(15,12))
explode = (0, 0, 0, 0.2, 0.3, 0.3, 0.2, 0.1) 
ax.pie(df["count"], labels=df["group_name"], autopct='%1.2f%%', startangle=160, shadow=False, explode=explode)
ax.axis('equal')
plt.tight_layout()
plt.show()
```


![png](output_14_0.png)



```python
fig
```




![png](output_15_0.png)




```python
ax
```




    <matplotlib.axes._subplots.AxesSubplot at 0x27ddefd4ac0>




```python
group_name = "Computer Science"
cats = data.merge(df_taxonomy, on="categories").query("group_name == @group_name")
cats
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>year</th>
      <th>group_name</th>
      <th>archive_name</th>
      <th>archive_id</th>
      <th>category_name</th>
      <th>category_description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>38628</th>
      <td>0705.0599</td>
      <td>cs.HC</td>
      <td>2020</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Human-Computer Interaction</td>
      <td>Covers human factors, user interfaces, and col...</td>
    </tr>
    <tr>
      <th>38629</th>
      <td>1007.5158</td>
      <td>cs.HC</td>
      <td>2019</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Human-Computer Interaction</td>
      <td>Covers human factors, user interfaces, and col...</td>
    </tr>
    <tr>
      <th>38630</th>
      <td>1401.7735</td>
      <td>cs.HC</td>
      <td>2019</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Human-Computer Interaction</td>
      <td>Covers human factors, user interfaces, and col...</td>
    </tr>
    <tr>
      <th>38631</th>
      <td>1410.1648</td>
      <td>cs.HC</td>
      <td>2019</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Human-Computer Interaction</td>
      <td>Covers human factors, user interfaces, and col...</td>
    </tr>
    <tr>
      <th>38632</th>
      <td>1603.02642</td>
      <td>cs.HC</td>
      <td>2020</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Human-Computer Interaction</td>
      <td>Covers human factors, user interfaces, and col...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>182361</th>
      <td>1908.09549</td>
      <td>cs.GL</td>
      <td>2019</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>General Literature</td>
      <td>Covers introductory material, survey material,...</td>
    </tr>
    <tr>
      <th>182362</th>
      <td>2003.01771</td>
      <td>cs.GL</td>
      <td>2020</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>General Literature</td>
      <td>Covers introductory material, survey material,...</td>
    </tr>
    <tr>
      <th>182363</th>
      <td>2006.11842</td>
      <td>cs.GL</td>
      <td>2020</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>General Literature</td>
      <td>Covers introductory material, survey material,...</td>
    </tr>
    <tr>
      <th>182364</th>
      <td>2008.12672</td>
      <td>cs.GL</td>
      <td>2020</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>General Literature</td>
      <td>Covers introductory material, survey material,...</td>
    </tr>
    <tr>
      <th>182365</th>
      <td>2010.00506</td>
      <td>cs.GL</td>
      <td>2020</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>Computer Science</td>
      <td>General Literature</td>
      <td>Covers introductory material, survey material,...</td>
    </tr>
  </tbody>
</table>
<p>40067 rows × 8 columns</p>
</div>




```python
gb = cats.groupby(["year", "category_name"])
gb.size()
```




    year  category_name                                  
    2019  Artificial Intelligence                             558
          Computation and Language                           2153
          Computational Complexity                            131
          Computational Engineering, Finance, and Science     108
          Computational Geometry                              199
                                                             ... 
    2020  Social and Information Networks                     325
          Software Engineering                                804
          Sound                                                 4
          Symbolic Computation                                 36
          Systems and Control                                 133
    Length: 78, dtype: int64




```python
cats.groupby(["year", "category_name"]).count()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>id</th>
      <th>categories</th>
      <th>group_name</th>
      <th>archive_name</th>
      <th>archive_id</th>
      <th>category_description</th>
    </tr>
    <tr>
      <th>year</th>
      <th>category_name</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">2019</th>
      <th>Artificial Intelligence</th>
      <td>558</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
    </tr>
    <tr>
      <th>Computation and Language</th>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
    </tr>
    <tr>
      <th>Computational Complexity</th>
      <td>131</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
    </tr>
    <tr>
      <th>Computational Engineering, Finance, and Science</th>
      <td>108</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
    </tr>
    <tr>
      <th>Computational Geometry</th>
      <td>199</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">2020</th>
      <th>Social and Information Networks</th>
      <td>325</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
    </tr>
    <tr>
      <th>Software Engineering</th>
      <td>804</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
    </tr>
    <tr>
      <th>Sound</th>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Symbolic Computation</th>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
    </tr>
    <tr>
      <th>Systems and Control</th>
      <td>133</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
    </tr>
  </tbody>
</table>
<p>78 rows × 6 columns</p>
</div>




```python
cats.groupby(["year", "category_name"]).count().reset_index()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>year</th>
      <th>category_name</th>
      <th>id</th>
      <th>categories</th>
      <th>group_name</th>
      <th>archive_name</th>
      <th>archive_id</th>
      <th>category_description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2019</td>
      <td>Artificial Intelligence</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
      <td>558</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2019</td>
      <td>Computation and Language</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
      <td>2153</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2019</td>
      <td>Computational Complexity</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
      <td>131</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2019</td>
      <td>Computational Engineering, Finance, and Science</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
      <td>108</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2019</td>
      <td>Computational Geometry</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
      <td>199</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>73</th>
      <td>2020</td>
      <td>Social and Information Networks</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
      <td>325</td>
    </tr>
    <tr>
      <th>74</th>
      <td>2020</td>
      <td>Software Engineering</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
      <td>804</td>
    </tr>
    <tr>
      <th>75</th>
      <td>2020</td>
      <td>Sound</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
      <td>4</td>
    </tr>
    <tr>
      <th>76</th>
      <td>2020</td>
      <td>Symbolic Computation</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
    </tr>
    <tr>
      <th>77</th>
      <td>2020</td>
      <td>Systems and Control</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
      <td>133</td>
    </tr>
  </tbody>
</table>
<p>78 rows × 8 columns</p>
</div>




```python
cats.groupby(["year", "category_name"]).count().reset_index().pivot(index="category_name", columns="year", values="id")

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>year</th>
      <th>2019</th>
      <th>2020</th>
    </tr>
    <tr>
      <th>category_name</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Artificial Intelligence</th>
      <td>558</td>
      <td>757</td>
    </tr>
    <tr>
      <th>Computation and Language</th>
      <td>2153</td>
      <td>2906</td>
    </tr>
    <tr>
      <th>Computational Complexity</th>
      <td>131</td>
      <td>188</td>
    </tr>
    <tr>
      <th>Computational Engineering, Finance, and Science</th>
      <td>108</td>
      <td>205</td>
    </tr>
    <tr>
      <th>Computational Geometry</th>
      <td>199</td>
      <td>216</td>
    </tr>
    <tr>
      <th>Computer Science and Game Theory</th>
      <td>281</td>
      <td>323</td>
    </tr>
    <tr>
      <th>Computer Vision and Pattern Recognition</th>
      <td>5559</td>
      <td>6517</td>
    </tr>
    <tr>
      <th>Computers and Society</th>
      <td>346</td>
      <td>564</td>
    </tr>
    <tr>
      <th>Cryptography and Security</th>
      <td>1067</td>
      <td>1238</td>
    </tr>
    <tr>
      <th>Data Structures and Algorithms</th>
      <td>711</td>
      <td>902</td>
    </tr>
    <tr>
      <th>Databases</th>
      <td>282</td>
      <td>342</td>
    </tr>
    <tr>
      <th>Digital Libraries</th>
      <td>125</td>
      <td>157</td>
    </tr>
    <tr>
      <th>Discrete Mathematics</th>
      <td>84</td>
      <td>81</td>
    </tr>
    <tr>
      <th>Distributed, Parallel, and Cluster Computing</th>
      <td>715</td>
      <td>774</td>
    </tr>
    <tr>
      <th>Emerging Technologies</th>
      <td>101</td>
      <td>84</td>
    </tr>
    <tr>
      <th>Formal Languages and Automata Theory</th>
      <td>152</td>
      <td>137</td>
    </tr>
    <tr>
      <th>General Literature</th>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Graphics</th>
      <td>116</td>
      <td>151</td>
    </tr>
    <tr>
      <th>Hardware Architecture</th>
      <td>95</td>
      <td>159</td>
    </tr>
    <tr>
      <th>Human-Computer Interaction</th>
      <td>420</td>
      <td>580</td>
    </tr>
    <tr>
      <th>Information Retrieval</th>
      <td>245</td>
      <td>331</td>
    </tr>
    <tr>
      <th>Logic in Computer Science</th>
      <td>470</td>
      <td>504</td>
    </tr>
    <tr>
      <th>Machine Learning</th>
      <td>177</td>
      <td>538</td>
    </tr>
    <tr>
      <th>Mathematical Software</th>
      <td>27</td>
      <td>45</td>
    </tr>
    <tr>
      <th>Multiagent Systems</th>
      <td>85</td>
      <td>90</td>
    </tr>
    <tr>
      <th>Multimedia</th>
      <td>76</td>
      <td>66</td>
    </tr>
    <tr>
      <th>Networking and Internet Architecture</th>
      <td>864</td>
      <td>783</td>
    </tr>
    <tr>
      <th>Neural and Evolutionary Computing</th>
      <td>235</td>
      <td>279</td>
    </tr>
    <tr>
      <th>Numerical Analysis</th>
      <td>40</td>
      <td>11</td>
    </tr>
    <tr>
      <th>Operating Systems</th>
      <td>36</td>
      <td>33</td>
    </tr>
    <tr>
      <th>Other Computer Science</th>
      <td>67</td>
      <td>69</td>
    </tr>
    <tr>
      <th>Performance</th>
      <td>45</td>
      <td>51</td>
    </tr>
    <tr>
      <th>Programming Languages</th>
      <td>268</td>
      <td>294</td>
    </tr>
    <tr>
      <th>Robotics</th>
      <td>917</td>
      <td>1298</td>
    </tr>
    <tr>
      <th>Social and Information Networks</th>
      <td>202</td>
      <td>325</td>
    </tr>
    <tr>
      <th>Software Engineering</th>
      <td>659</td>
      <td>804</td>
    </tr>
    <tr>
      <th>Sound</th>
      <td>7</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Symbolic Computation</th>
      <td>44</td>
      <td>36</td>
    </tr>
    <tr>
      <th>Systems and Control</th>
      <td>415</td>
      <td>133</td>
    </tr>
  </tbody>
</table>
</div>




```python
cat = cats.groupby(["year", "category_name"]).count().reset_index().pivot(index="category_name", columns="year", values="id")
cat.columns
```




    Int64Index([2019, 2020], dtype='int64', name='year')




```python
cat.sort_values([2020, 2019],ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>year</th>
      <th>2019</th>
      <th>2020</th>
    </tr>
    <tr>
      <th>category_name</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Computer Vision and Pattern Recognition</th>
      <td>5559</td>
      <td>6517</td>
    </tr>
    <tr>
      <th>Computation and Language</th>
      <td>2153</td>
      <td>2906</td>
    </tr>
    <tr>
      <th>Robotics</th>
      <td>917</td>
      <td>1298</td>
    </tr>
    <tr>
      <th>Cryptography and Security</th>
      <td>1067</td>
      <td>1238</td>
    </tr>
    <tr>
      <th>Data Structures and Algorithms</th>
      <td>711</td>
      <td>902</td>
    </tr>
    <tr>
      <th>Software Engineering</th>
      <td>659</td>
      <td>804</td>
    </tr>
    <tr>
      <th>Networking and Internet Architecture</th>
      <td>864</td>
      <td>783</td>
    </tr>
    <tr>
      <th>Distributed, Parallel, and Cluster Computing</th>
      <td>715</td>
      <td>774</td>
    </tr>
    <tr>
      <th>Artificial Intelligence</th>
      <td>558</td>
      <td>757</td>
    </tr>
    <tr>
      <th>Human-Computer Interaction</th>
      <td>420</td>
      <td>580</td>
    </tr>
    <tr>
      <th>Computers and Society</th>
      <td>346</td>
      <td>564</td>
    </tr>
    <tr>
      <th>Machine Learning</th>
      <td>177</td>
      <td>538</td>
    </tr>
    <tr>
      <th>Logic in Computer Science</th>
      <td>470</td>
      <td>504</td>
    </tr>
    <tr>
      <th>Databases</th>
      <td>282</td>
      <td>342</td>
    </tr>
    <tr>
      <th>Information Retrieval</th>
      <td>245</td>
      <td>331</td>
    </tr>
    <tr>
      <th>Social and Information Networks</th>
      <td>202</td>
      <td>325</td>
    </tr>
    <tr>
      <th>Computer Science and Game Theory</th>
      <td>281</td>
      <td>323</td>
    </tr>
    <tr>
      <th>Programming Languages</th>
      <td>268</td>
      <td>294</td>
    </tr>
    <tr>
      <th>Neural and Evolutionary Computing</th>
      <td>235</td>
      <td>279</td>
    </tr>
    <tr>
      <th>Computational Geometry</th>
      <td>199</td>
      <td>216</td>
    </tr>
    <tr>
      <th>Computational Engineering, Finance, and Science</th>
      <td>108</td>
      <td>205</td>
    </tr>
    <tr>
      <th>Computational Complexity</th>
      <td>131</td>
      <td>188</td>
    </tr>
    <tr>
      <th>Hardware Architecture</th>
      <td>95</td>
      <td>159</td>
    </tr>
    <tr>
      <th>Digital Libraries</th>
      <td>125</td>
      <td>157</td>
    </tr>
    <tr>
      <th>Graphics</th>
      <td>116</td>
      <td>151</td>
    </tr>
    <tr>
      <th>Formal Languages and Automata Theory</th>
      <td>152</td>
      <td>137</td>
    </tr>
    <tr>
      <th>Systems and Control</th>
      <td>415</td>
      <td>133</td>
    </tr>
    <tr>
      <th>Multiagent Systems</th>
      <td>85</td>
      <td>90</td>
    </tr>
    <tr>
      <th>Emerging Technologies</th>
      <td>101</td>
      <td>84</td>
    </tr>
    <tr>
      <th>Discrete Mathematics</th>
      <td>84</td>
      <td>81</td>
    </tr>
    <tr>
      <th>Other Computer Science</th>
      <td>67</td>
      <td>69</td>
    </tr>
    <tr>
      <th>Multimedia</th>
      <td>76</td>
      <td>66</td>
    </tr>
    <tr>
      <th>Performance</th>
      <td>45</td>
      <td>51</td>
    </tr>
    <tr>
      <th>Mathematical Software</th>
      <td>27</td>
      <td>45</td>
    </tr>
    <tr>
      <th>Symbolic Computation</th>
      <td>44</td>
      <td>36</td>
    </tr>
    <tr>
      <th>Operating Systems</th>
      <td>36</td>
      <td>33</td>
    </tr>
    <tr>
      <th>Numerical Analysis</th>
      <td>40</td>
      <td>11</td>
    </tr>
    <tr>
      <th>General Literature</th>
      <td>5</td>
      <td>5</td>
    </tr>
    <tr>
      <th>Sound</th>
      <td>7</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
